from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='Poisk bukv',
    author='Darean',
    author_email='aaa@aaa.com',
    url='aaaaa.com',
    py_modules=['vsearch'],
)

